#ifndef VSF_VERSION_H
#define VSF_VERSION_H

#define VSF_VERSION "1.1.0"

#endif /* VSF_VERSION_H */

