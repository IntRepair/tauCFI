#ifndef VSF_DIRFD_EXTRAS_H
#define VSF_DIRFD_EXTRAS_H

#define dirfd(x) ((x)->dd_fd)

#endif /* VSF_DIRFD_EXTRAS_H */

