#  ifdef DEREF_KLUDGE
         sm31             = grid%sm31
         em31             = grid%em31
         sm32             = grid%sm32
         em32             = grid%em32
         sm33             = grid%sm33
         em33             = grid%em33
#  endif

