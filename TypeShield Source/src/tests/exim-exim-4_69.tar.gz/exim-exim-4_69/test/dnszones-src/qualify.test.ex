$Cambridge: exim/test/dnszones-src/qualify.test.ex,v 1.1 2006/02/06 16:22:56 ph10 Exp $

The contents of this file are not used. Its name is used as a way of specifying
the domain that is to be used to qualify unqualified domain names when given to
the fake DNS resolver.
