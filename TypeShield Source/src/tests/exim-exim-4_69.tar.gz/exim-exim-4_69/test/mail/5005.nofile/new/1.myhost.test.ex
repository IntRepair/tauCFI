Received: from CALLER by myhost.test.ex with local (Exim x.yz)
	(envelope-from <CALLER@test.ex>)
	id 10HmaX-0005vi-00
	for nofile@test.ex; Tue, 2 Mar 1999 09:44:33 +0000
Message-Id: <E10HmaX-0005vi-00@myhost.test.ex>
From: CALLER_NAME <CALLER@test.ex>
Date: Tue, 2 Mar 1999 09:44:33 +0000

Message for nofile
