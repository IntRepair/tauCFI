SET client_min_messages = warning;
\set ECHO none
\i btree_gin.sql
\set ECHO all
RESET client_min_messages;
